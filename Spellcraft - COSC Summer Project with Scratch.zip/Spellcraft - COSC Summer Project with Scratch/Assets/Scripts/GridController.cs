﻿using System.Collections;
using System;
using System.Linq;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GridController : MonoBehaviour
{
    [Serializable]
    public class Count
    {
        public int minimum;
        public int maximum;

        public Count(int min, int max)
        {
            minimum = min;
            maximum = max;
        }
    }

    public int rows = 8;
    public int columns = 8;
    public GameObject combatTilePrefab;
    public GameObject debugPrefab;
    public Sprite[] backgroundSprites;
    public Sprite[] borderSprites;
    public Sprite[] obstacleSprites;
    public Count obstacleCount;
    
    private GameObject combatUI;
    private float tileScale;
    private Vector3 tileOffset;
    private RectTransform gridPanel;
    private List<CombatTile> tiles = new List<CombatTile>();

    // Initialize the parent object of the grid tiles and calculate the proper UI scaling
    private void InitializeGridPanel()
    {
        combatUI = GameObject.Find("CombatUI");
        gridPanel = (RectTransform) combatUI.transform.Find("GridPanel");

        // Scale UI with screen dimensions and center the grid in its window 
        float hScale = combatUI.GetComponent<RectTransform>().rect.width * (gridPanel.anchorMax.x - gridPanel.anchorMin.x) / (columns + 2);
        float vScale = combatUI.GetComponent<RectTransform>().rect.height * (gridPanel.anchorMax.y - gridPanel.anchorMin.y) / (rows + 2);
        // Scale to the smaller of vertical or horizontal dimensions
        tileScale = hScale > vScale ? vScale : hScale;
        tileOffset = new Vector3(tileScale * ((columns / 2.0f) - 0.5f), tileScale * ((rows / 2.0f) - 0.5f), 0f);
    }

    // Initialize all background and border tiles
    private void InitializeTiles()
    {
        for (int x = -1; x < columns + 1; x++)
        {
            for (int y = -1; y < rows + 1; y++)
            {
                // Border tiles
                if (x == -1 || x == columns || y == -1 || y == rows)
                {
                    CombatTile tile = Instantiate(combatTilePrefab, Vector3.zero, Quaternion.identity, gridPanel).GetComponent<CombatTile>();
                    Vector3 gridPosition = new Vector3(x, y, 0f);
                    SetScreenPosition(tile.gameObject, gridPosition);
                    tile.gridPosition = gridPosition;
                    tile.isBorder = true;
                    tile.GetComponent<BoxCollider2D>().isTrigger = false;
                    tile.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
                    tile.GetComponent<Image>().sprite = borderSprites[UnityEngine.Random.Range(0, borderSprites.Length)];
                    tiles.Add(tile);
                }
                // Background tiles
                else
                {
                    CombatTile tile = Instantiate(combatTilePrefab, Vector3.zero, Quaternion.identity, gridPanel).GetComponent<CombatTile>();
                    Vector3 gridPosition = new Vector3(x, y, 0f);
                    SetScreenPosition(tile.gameObject, gridPosition);
                    tile.gridPosition = gridPosition;
                    tile.isBorder = false;
                    tile.GetComponent<BoxCollider2D>().isTrigger = true;
                    tile.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
                    tile.GetComponent<Image>().sprite = backgroundSprites[UnityEngine.Random.Range(0, backgroundSprites.Length)];
                    tiles.Add(tile);

                    // Debug tile numbering
                    GameObject debug = Instantiate(debugPrefab, Vector3.zero, Quaternion.identity, gridPanel) as GameObject;
                    SetScreenPosition(debug, new Vector3(x, y, 0f));
                    debug.GetComponent<Text>().text = "[" + x + "," + y + "]";
                }
            }
        }
    }

    // Initialize the list of all possible grid object spawn positions
    private void InitializeObjectSpawnPositions()
    {
        tiles.ForEach(tile => tile.isObjectSpawnLocation = false);

        for (int x = 0; x < columns; x++)
        {
            for (int y = 1; y < rows - 1; y++)
            {
                CombatTile tile = GetTile(new Vector3(x, y, 0f));
                tile.isObjectSpawnLocation = true;
                tile.hasSpawnedObject = false;
            }
        }
    }

    // Initialize the list of all possible enemy spawn positions
    private void InitializeEnemySpawnPositions()
    {
        tiles.ForEach(tile => tile.isEnemySpawnLocation = false);

        for (int x = 0; x < columns; x++)
        {
            CombatTile tile = GetTile(new Vector3(x, rows - 1, 0f));
            tile.isEnemySpawnLocation = true;
            tile.hasSpawnedObject = false;
        }
    }
    
    private Vector3 GetRandomItemSpawnPosition()
    {
        List<CombatTile> availableTiles = tiles.Where(tile => tile.isObjectSpawnLocation && !tile.hasSpawnedObject).ToList();
        int randIndex = UnityEngine.Random.Range(0, availableTiles.Count);
        Vector3 position = availableTiles[randIndex].gridPosition;
        availableTiles[randIndex].hasSpawnedObject = true;
        return position;
    }
    
    private Vector3 GetRandomEnemySpawnPosition()
    {
        List<CombatTile> availableTiles = tiles.Where(tile => tile.isEnemySpawnLocation && !tile.hasSpawnedEnemy).ToList();
        int randIndex = UnityEngine.Random.Range(0, availableTiles.Count);
        Vector3 position = availableTiles[randIndex].gridPosition;
        availableTiles[randIndex].hasSpawnedEnemy = true;
        return position;
    }

    // Place a random selection of objects on the grid anywhere but the top and bottom rows
    private void PlaceItemsAtRandom(GameObject prefab, Sprite[] sprites, Count count)
    {
        int numObjects = UnityEngine.Random.Range(count.minimum, count.maximum);

        for (int i = 0; i < numObjects; i++)
        {
            Vector3 randPosition = GetRandomItemSpawnPosition();
            GameObject item = Instantiate(prefab, Vector3.zero, Quaternion.identity, gridPanel) as GameObject;
            SetScreenPosition(item, randPosition);
            item.GetComponent<CombatTile>().gridPosition = randPosition;
            item.GetComponent<BoxCollider2D>().isTrigger = false;
            item.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
            item.GetComponent<Image>().sprite = sprites[UnityEngine.Random.Range(0, sprites.Length)];
        }
    }

    // Place enemies at random locations along the top row of the grid
    private void PlaceEnemiesAtRandom(GameObject[] enemies)
    {
        for (int i = 0; i < enemies.Length; i++)
        {
            Vector3 spawnPosition = GetRandomEnemySpawnPosition();
            GameObject enemy = Instantiate(enemies[i], Vector3.zero, Quaternion.identity, gridPanel) as GameObject;
            enemy.GetComponent<Enemy>().SetGridPosition(spawnPosition);
            enemy.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
        }
    }
    
    // Scales a grid position based on screen dimensions and the offset of the grid in the UI
    private Vector3 ScaleToScreenSize(Vector3 gridPosition)
    {
        Vector3 result = Vector3.zero;
        result.x = gridPosition.x * tileScale;
        result.y = gridPosition.y * tileScale;
        result.z = gridPosition.z;
        result -= tileOffset;
        return result;
    }

    public void SetGridInteractible(bool interactible)
    {
        tiles.Where(tile => !tile.isBorder).ToList()
            .ForEach(tile => tile.interactible = interactible);
    }

    public void SetScreenPosition(GameObject target, Vector3 gridPosition)
    {
        target.GetComponent<RectTransform>().anchoredPosition = ScaleToScreenSize(gridPosition);
    }
    
    public CombatTile GetTile(Vector3 gridPosition)
    {
        foreach (CombatTile tile in tiles)
            if (tile.gridPosition == gridPosition)
                return tile;

        return null;
    }

    // Initialize all static parts of the grid
    public void InitializeGrid()
    {
        InitializeGridPanel();
        InitializeTiles();
        InitializeObjectSpawnPositions();
        PlaceItemsAtRandom(combatTilePrefab, obstacleSprites, obstacleCount);
        SetGridInteractible(false);
    }

    public void SpawnEnemies(GameObject[] enemies)
    {
        InitializeEnemySpawnPositions();
        PlaceEnemiesAtRandom(enemies);
    }
    
    public void SpawnPlayer(GameObject player)
    {
        GameObject playerInstance = Instantiate(player, Vector3.zero, Quaternion.identity, gridPanel) as GameObject;
        Vector3 gridPosition = new Vector3(columns / 2, 0f, 0f);
        playerInstance.GetComponent<Player>().SetGridPosition(gridPosition);
        playerInstance.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
    }
}
