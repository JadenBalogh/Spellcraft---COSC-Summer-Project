﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class SpellController : MonoBehaviour {
    
    [HideInInspector]
    public Spell activeSpell;
    
    private List<Spell> spells;
    private Player player;

    private void Awake()
    {
        spells = new List<Spell>();
    }

    private void CheckPlayer()
    {
        if (player == null)
            player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }

    public void AddSpell(Spell spell)
    {
        spells.Add(spell);
    }

    public void CheckAvailableSpells()
    {
        CheckPlayer();
        spells.ForEach(spell => spell.SetInteractable(spell.IsAvailable()));
    }
    
    public void UseActiveSpell(Vector3 position)
    {
        activeSpell.Use(position);
    }
}
