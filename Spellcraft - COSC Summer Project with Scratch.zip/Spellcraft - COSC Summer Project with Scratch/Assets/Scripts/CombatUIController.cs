﻿using System.Collections;
using System.Collections.Generic;
using System.Runtime.InteropServices;
using UnityEngine;
using UnityEngine.UI;

public class CombatUIController : MonoBehaviour
{
    private GameController gameController;
    private SpellController spellController;
    private Player player;

    [DllImport("__Internal")]
    private static extern void Hello();

    private void Awake()
    {
        gameController = GameController.instance;
        spellController = gameController.spellController;
    }

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }

    public void EndPlayersTurn()
    {
        gameController.playersTurn = false;
    }

    public void SetActiveSpell(Spell spell)
    {
        spellController.activeSpell = spell;
        Hello();
    }
}
