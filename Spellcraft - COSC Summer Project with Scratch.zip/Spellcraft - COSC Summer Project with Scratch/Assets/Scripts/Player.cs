﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int maxEnergy = 1;
    public int maxMana = 1;
    public int maxHealth = 1;
    
    private GameController gameController;
    private GridController gridController;
    private SpellController spellController;
    private CombatTile currentTile;
    private int energy;
    private int mana;
    private int health;
    private float movementTimer;

	private void Awake ()
    {
        gameController = GameController.instance;
        gridController = gameController.gridController;
        spellController = gameController.spellController;
        gameController.SetPlayer(this);
	}

    private void Start()
    {
        ResetStats();
    }

    private void Update ()
    {
        movementTimer += Time.deltaTime;
        
        if (gameController.playersTurn)
        {
            int h = (int)Input.GetAxisRaw("Horizontal");
            int v = (int)Input.GetAxisRaw("Vertical");

            if ((h != 0 || v != 0) && energy > 0 && movementTimer > gameController.moveDelay)
            {
                Move(h, v);
            }
        }
	}

    private void Move(int x, int y)
    {
        ExpendEnergy(1);
        Vector3 translation = new Vector3(x, y, 0f);
        SetGridPosition(currentTile.gridPosition + translation);
        movementTimer = 0f;
    }

    public void SetGridPosition(Vector3 position)
    {
        CombatTile newTile = gridController.GetTile(position);
        if (newTile.activeObject != null)
            return;
        if (currentTile != null)
            currentTile.activeObject = null;
        newTile.activeObject = gameObject;
        currentTile = newTile;
        gridController.SetScreenPosition(gameObject, position);
    }

    public void EndTurn()
    {
        gameController.playersTurn = false;
    }

    public Vector3 GetGridPosition()
    {
        return currentTile.gridPosition;
    }

    public int GetHealth()
    {
        return health;
    }

    private void SetHealth(int health)
    {
        this.health = health;
    }

    public void TakeDamage(int damage)
    {
        SetHealth(health - damage);
    }

    public int GetMana()
    {
        return mana;
    }

    private void SetMana(int mana)
    {
        this.mana = mana;
        spellController.CheckAvailableSpells();
        Debug.Log("Mana: " + mana + "/" + maxMana);
    }
    
    public void SpendMana(int cost)
    {
        SetMana(mana - cost);
    }

    public void ExpendEnergy(int loss)
    {
        energy -= loss;
    }

    public void ResetStats()
    {
        energy = maxEnergy;
        SetMana(maxMana);
        SetHealth(maxHealth);
    }
}
