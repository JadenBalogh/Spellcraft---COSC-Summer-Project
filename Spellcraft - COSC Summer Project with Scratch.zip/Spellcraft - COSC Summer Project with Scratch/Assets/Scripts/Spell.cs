﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

[Serializable]
public class Spell : MonoBehaviour
{
    public GameObject vfxPrefab;
    public string spellName;
    public int damage;
    public int manaCost;
    public Text spellText;

    private GameController gameController;
    private GridController gridController;
    private SpellController spellController;
    private Player player;

    private void Awake()
    {
        gameController = GameController.instance;
        gridController = gameController.gridController;
        spellController = gameController.spellController;
        spellController.AddSpell(this);
    }

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        UpdateUI();
    }

    private void UpdateUI()
    {
        spellText.text = "\"" + spellName + "\" | DMG: " + damage + " | MC: " + manaCost;
    }

    public bool IsAvailable()
    {
        return player.GetMana() >= manaCost;
    }

    public void SetInteractable(bool interactable)
    {
        GetComponent<Button>().interactable = interactable;
    }
    
    public void Use(Vector3 position)
    {
        Debug.Log("Spell Used.");
        GameObject target = gridController.GetTile(position).activeObject;
        if (target != null)
        {
            Debug.Log("Target Found.");
            Enemy enemy = target.GetComponent<Enemy>();
            if (enemy != null)
            {
                Debug.Log("Enemy Found.");
                enemy.TakeDamage(damage);
            }
        }
        spellController.activeSpell = null;
        player.SpendMana(manaCost);
        UpdateUI();
    }
}
