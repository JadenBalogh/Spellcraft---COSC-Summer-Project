﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;

[RequireComponent(typeof(BoxCollider2D), typeof(Rigidbody2D), typeof(Image))]
public class CombatTile : MonoBehaviour, IPointerEnterHandler, IPointerClickHandler, IPointerExitHandler {

    public Color idleColor = Color.white;
    public Color hoverColor = Color.yellow;
    public Color clickColor = Color.red;
    public float clickAnimationDelay;

    [HideInInspector]
    public Vector3 gridPosition;
    [HideInInspector]
    public GameObject activeObject;
    [HideInInspector]
    public bool interactible;
    [HideInInspector]
    public bool isBorder;
    [HideInInspector]
    public bool isEnemySpawnLocation;
    [HideInInspector]
    public bool hasSpawnedEnemy;
    [HideInInspector]
    public bool isObjectSpawnLocation;
    [HideInInspector]
    public bool hasSpawnedObject;

    private GameController gameController;
    private SpellController spellController;

    private void Awake()
    {
        gameController = GameController.instance;
        spellController = gameController.spellController;
    }

    void IPointerEnterHandler.OnPointerEnter(PointerEventData eventData)
    {
        if (interactible)
        {
            GetComponent<Image>().color = hoverColor;
        }
    }

    void IPointerClickHandler.OnPointerClick(PointerEventData eventData)
    {
        if (interactible)
        {
            if (spellController.activeSpell != null)
            {
                spellController.UseActiveSpell(gridPosition);
                StartCoroutine(ClickAnimation());
            }
        }
    }

    private IEnumerator ClickAnimation()
    {
        GetComponent<Image>().color = clickColor;
        yield return new WaitForSeconds(clickAnimationDelay);
        GetComponent<Image>().color = idleColor;
    }
    
    void IPointerExitHandler.OnPointerExit(PointerEventData eventData)
    {
        GetComponent<Image>().color = idleColor;
    }
}
