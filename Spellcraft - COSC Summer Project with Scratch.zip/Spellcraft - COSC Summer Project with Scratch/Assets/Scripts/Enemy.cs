﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Enemy : MonoBehaviour
{
    public int maxHealth = 1;
    
    private GameController gameController;
    private GridController gridController;
    private CombatTile currentTile;
    private Player player;
    private int health;

    private void Awake ()
    {
        gameController = GameController.instance;
        gridController = gameController.gridController;
        gameController.AddEnemy(this);
        ResetStats();
    }

    private void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }

    public void TakeDamage(int damage)
    {
        if (health > 0)
        {
            health -= damage;
            Debug.Log(gameObject + " health: " + health + "/" + maxHealth);
            if (health <= 0)
            {
                gameController.RemoveEnemy(this);
                Destroy(gameObject);
            }
        }
    }
    
    public void Move()
    {
        Vector3 playerPos = player.GetGridPosition();
        int xDist = (int)Mathf.Abs(playerPos.x - currentTile.gridPosition.x);
        int yDist = (int)Mathf.Abs(playerPos.y - currentTile.gridPosition.y);
        Vector3 translation = Vector3.zero;
        if (xDist > yDist)
        {
            translation.x = playerPos.x > currentTile.gridPosition.x ? 1 : -1;
        }
        else
        {
            translation.y = playerPos.y > currentTile.gridPosition.y ? 1 : -1;
        }
        SetGridPosition(currentTile.gridPosition + translation);
    }

    public void SetGridPosition(Vector3 position)
    {
        CombatTile newTile = gridController.GetTile(position);
        if (newTile.activeObject != null)
            return;
        if (currentTile != null)
            currentTile.activeObject = null;
        newTile.activeObject = gameObject;
        currentTile = newTile;
        gridController.SetScreenPosition(gameObject, position);
    }

    public void ResetStats()
    {
        health = maxHealth;
    }
}
