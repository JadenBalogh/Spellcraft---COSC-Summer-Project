﻿using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class SpellController : MonoBehaviour {
    
    [HideInInspector]
    public Spell activeSpell;

    private GameObject combatUI;
    private RectTransform spellPanel;
    private List<Spell> spells;
    private Player player;

    void Awake()
    {
        spells = new List<Spell>();
    }

    void CheckPlayer()
    {
        if (player == null)
            player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
    }

    public void AddSpell(Spell spell)
    {
        spells.Add(spell);
    }

    public void CheckAvailableSpells()
    {
        CheckPlayer();
        spells.ForEach(spell => spell.SetAvailable(player.CanUseSpell(spell)));
    }

    public void InitializeSpellPanel()
    {
        combatUI = GameObject.Find("CombatUI");
        spellPanel = (RectTransform) combatUI.transform.Find("SpellPanel");
    }

    public void UseActiveSpell(Vector3 position)
    {
        activeSpell.Use(position);
    }
}
