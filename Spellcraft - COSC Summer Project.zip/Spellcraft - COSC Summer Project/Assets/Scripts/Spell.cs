﻿using System.Collections;
using System.Collections.Generic;
using System;
using UnityEngine;
using UnityEngine.UI;

[Serializable]
public class Spell : MonoBehaviour
{
    public GameObject vfxPrefab;
    public string spellName;
    public int damage;
    public int manaCost;
    public Text spellText;

    private GameController gameController;
    private GridController gridController;
    private SpellController spellController;
    private Player player;

    void Awake()
    {
        gameController = GameController.instance;
        gridController = gameController.gridController;
        spellController = gameController.spellController;
        spellController.AddSpell(this);
    }

    void Start()
    {
        player = GameObject.FindGameObjectWithTag("Player").GetComponent<Player>();
        UpdateUI();
    }

    void UpdateUI()
    {
        spellText.text = "\"" + spellName + "\" | DMG: " + damage + " | MC: " + manaCost;
    }

    public void SetAvailable(bool available)
    {
        GetComponent<Button>().interactable = available;
    }
    
    public void MakeActiveSpell()
    {
        spellController.activeSpell = this;
    }
    
    public void Use(Vector3 position)
    {
        Debug.Log("Spell Used.");
        GameObject target = gridController.GetTile(position).activeObject;
        if (target != null)
        {
            Debug.Log("Target Found.");
            Enemy enemy = target.GetComponent<Enemy>();
            if (enemy != null)
            {
                Debug.Log("Enemy Found.");
                enemy.TakeDamage(damage);
            }
        }
        spellController.activeSpell = null;
        player.SpendMana(manaCost);
        UpdateUI();
    }
}
