﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int maxEnergy = 1;
    public int maxMana = 1;
    public int maxHealth = 1;
    
    private GameController gameController;
    private GridController gridController;
    private SpellController spellController;
    private CombatTile currentTile;
    private int energy;
    private int mana;
    private int health;
    private float movementTimer;

	void Awake ()
    {
        gameController = GameController.instance;
        gridController = gameController.gridController;
        spellController = gameController.spellController;
        gameController.SetPlayer(this);
        ResetStats();
	}
	
	void Update ()
    {
        movementTimer += Time.deltaTime;

        //temp for debug
        if (energy <= 0)
            gameController.playersTurn = false;

        if (gameController.playersTurn)
        {
            int h = (int)Input.GetAxisRaw("Horizontal");
            int v = (int)Input.GetAxisRaw("Vertical");

            if ((h != 0 || v != 0) && energy > 0 && movementTimer > gameController.moveDelay)
            {
                Move(h, v);
            }
        }
	}

    void Move(int x, int y)
    {
        ExpendEnergy(1);
        Vector3 translation = new Vector3(x, y, 0f);
        SetGridPosition(currentTile.gridPosition + translation);
        movementTimer = 0f;
    }

    public void SetGridPosition(Vector3 position)
    {
        CombatTile newTile = gridController.GetTile(position);
        if (newTile.activeObject != null)
            return;
        if (currentTile != null)
            currentTile.activeObject = null;
        newTile.activeObject = gameObject;
        currentTile = newTile;
        gridController.SetScreenPosition(gameObject, position);
    }

    public Vector3 GetGridPosition()
    {
        return currentTile.gridPosition;
    }

    public bool CanUseSpell(Spell spell)
    {
        return mana >= spell.manaCost;
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
    }
    
    public void SpendMana(int cost)
    {
        mana -= cost;
        spellController.CheckAvailableSpells();
        Debug.Log("Mana: " + mana + "/" + maxMana);
    }

    public void ExpendEnergy(int loss)
    {
        energy -= loss;
    }

    public void ResetStats()
    {
        energy = maxEnergy;
        mana = maxMana;
        health = maxHealth;
    }
}
