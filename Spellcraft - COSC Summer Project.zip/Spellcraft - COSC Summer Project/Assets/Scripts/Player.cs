﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Player : MonoBehaviour
{
    public int maxEnergy = 1;
    public int maxMana = 1;
    public int maxHealth = 1;
    [HideInInspector]
    public Vector3 gridPosition;

    private int energy;
    private int mana;
    private int health;
    private float movementTimer;

	void Start ()
    {
        GameController.instance.SetPlayer(this);
        ResetStats();
	}
	
	void Update ()
    {
        movementTimer += Time.deltaTime;

        //temp for debug
        if (energy <= 0)
            GameController.instance.playersTurn = false;

        if (GameController.instance.playersTurn)
        {
            int h = (int)Input.GetAxisRaw("Horizontal");
            int v = (int)Input.GetAxisRaw("Vertical");

            if ((h != 0 || v != 0) && energy > 0 && movementTimer > GameController.instance.moveDelay)
            {
                Move(h, v);
            }
        }
	}

    void Move(int x, int y)
    {
        energy--;
        Vector3 translation = new Vector3(x, y, 0f);
        gridPosition += translation;
        GameController.instance.gridController.SetScreenPosition(gameObject, gridPosition);
        movementTimer = 0f;
    }

    public void TakeDamage(int damage)
    {
        health -= damage;
    }

    public void ResetStats()
    {
        energy = maxEnergy;
        mana = maxMana;
        health = maxHealth;
    }
}
