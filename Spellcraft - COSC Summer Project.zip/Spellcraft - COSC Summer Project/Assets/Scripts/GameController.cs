﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameController : MonoBehaviour
{
    public static GameController instance = null;
    public GameObject playerPrefab;
    public GameObject[] enemyPrefabs;
    public float turnDelay;
    public float moveDelay;
    [HideInInspector]
    public GridController gridController;
    [HideInInspector]
    public SpellController spellController;
    [HideInInspector]
    public bool playersTurn = true;

    private bool enemiesMoving = false;
    private List<Enemy> enemies;
    private Player player;

    // Ensure there is only one instance of GameController
    void Awake()
    {
        if (instance == null)
            instance = this;
        else if (instance != this)
            Destroy(gameObject);
        DontDestroyOnLoad(gameObject);
        gridController = GetComponent<GridController>();
        spellController = GetComponent<SpellController>();
        enemies = new List<Enemy>();
        playersTurn = true;
    }

    void Update()
    {
        if (playersTurn)
        {
            bool interactible = spellController.activeSpell != null;
            gridController.SetGridInteractible(interactible);
        }
        else if (!enemiesMoving)
        {
            StartCoroutine(MoveEnemies());
        }
    }

    IEnumerator MoveEnemies()
    {
        enemiesMoving = true;
        yield return new WaitForSeconds(turnDelay);

        for (int i = 0; i < enemies.Count; i++)
        {
            enemies[i].Move();
            yield return new WaitForSeconds(moveDelay);
        }

        player.ResetStats();
        playersTurn = true;
        enemiesMoving = false;
    }
    
    public void AddEnemy(Enemy enemy)
    {
        enemies.Add(enemy);
    }

    public void RemoveEnemy(Enemy enemy)
    {
        enemies.Remove(enemy);
    }
    
    public void SetPlayer(Player player)
    {
        this.player = player;
    }

    // Check which scene was loaded and initialize it
    public void OnLevelWasLoaded(int level)
    {
        if (SceneManager.GetSceneByBuildIndex(level).name.Equals("Combat"))
        {
            gridController.InitializeGrid();
            gridController.SpawnPlayer(playerPrefab);
            gridController.SpawnEnemies(enemyPrefabs);
            spellController.InitializeSpellPanel();
        }
    }
    
    public void LoadCombatScene()
    {
        SceneManager.LoadScene("Combat");
    }
}
