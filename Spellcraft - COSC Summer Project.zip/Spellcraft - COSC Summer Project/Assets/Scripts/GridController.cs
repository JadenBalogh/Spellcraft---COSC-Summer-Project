﻿using System.Collections;
using System;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class GridController : MonoBehaviour {

    [Serializable]
    public class Range {
        public int minimum;
        public int maximum;

        public Range(int min, int max)
        {
            minimum = min;
            maximum = max;
        }
    }

    public int rows = 8;
    public int columns = 8;
    public GameObject combatUIPrefab;
    public GameObject backgroundPrefab;
    public Sprite[] backgroundSprites;
    public GameObject borderPrefab;
    public Sprite[] borderSprites;
    public GameObject obstaclePrefab;
    public Sprite[] obstacleSprites;
    public Range obstacleCount;

    private GameObject combatUI;
    private float tileScale;
    private Vector3 tileOffset;
    private RectTransform gridHolder;
    private List<Vector3> availableGridPositions = new List<Vector3>();
    private List<Vector3> enemySpawnPositions = new List<Vector3>();

    void initializeGridHolder()
    {
        gridHolder = (RectTransform) combatUI.transform.Find("GridPanel");
        float hScale = combatUI.GetComponent<RectTransform>().rect.width * (gridHolder.anchorMax.x - gridHolder.anchorMin.x) / (columns + 2);
        float vScale = combatUI.GetComponent<RectTransform>().rect.height * (gridHolder.anchorMax.y - gridHolder.anchorMin.y) / (rows + 2);
        tileScale = hScale > vScale ? vScale : hScale;
        tileOffset = new Vector3(tileScale * ((columns / 2.0f) - 0.5f), tileScale * ((rows / 2.0f) - 0.5f), 0f);
    }

    void initializeBackground()
    {
        // Initialize all background and border tiles
        for (int x = -1; x < columns + 1; x++)
        {
            for (int y = -1; y < rows + 1; y++)
            {
                if (x == -1 || x == columns || y == -1 || y == rows)
                {
                    GameObject tile = Instantiate(borderPrefab, Vector3.zero, Quaternion.identity, gridHolder) as GameObject;
                    tile.GetComponent<RectTransform>().anchoredPosition = new Vector3(x * tileScale, y * tileScale, 0f) - tileOffset;
                    tile.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
                    tile.GetComponent<Image>().sprite = borderSprites[UnityEngine.Random.Range(0, borderSprites.Length)];
                }
                else
                {
                    GameObject tile = Instantiate(backgroundPrefab, Vector3.zero, Quaternion.identity, gridHolder) as GameObject;
                    tile.GetComponent<RectTransform>().anchoredPosition = new Vector3(x * tileScale, y * tileScale, 0f) - tileOffset;
                    tile.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
                    tile.GetComponent<Image>().sprite = backgroundSprites[UnityEngine.Random.Range(0, backgroundSprites.Length)];
                }
            }
        }
    }

    void initializeGridPositions()
    {
        availableGridPositions.Clear();

        // Initialize the list of all possible environment spawn positions
        for (int x = 0; x < columns; x++)
        {
            for (int y = 1; y < rows - 1; y++)
            {
                availableGridPositions.Add(new Vector3(x * tileScale, y * tileScale, 0f) - tileOffset);
            }
        }
    }

    void initializeEnemySpawnPositions()
    {
        enemySpawnPositions.Clear();

        // Initialize the list of all possible enemy spawn positions
        for (int x = 1; x < columns; x++)
        {
            enemySpawnPositions.Add(new Vector3(x * tileScale, (rows - 1) * tileScale, 0f) - tileOffset);
        }
    }

    void centerCamera()
    {
        Camera.main.orthographicSize = (rows / 2.0f) + 1;
        Camera.main.transform.position = new Vector3((columns / 2.0f) - 0.5f, (rows / 2.0f) - 0.5f, -10f);
    }

    Vector3 getRandomGridPosition()
    {
        int randIndex = UnityEngine.Random.Range(0, availableGridPositions.Count);
        Vector3 position = availableGridPositions[randIndex];
        availableGridPositions.RemoveAt(randIndex);
        return position;
    }
    
    Vector3 getRandomEnemySpawnPosition()
    {
        int randIndex = UnityEngine.Random.Range(0, enemySpawnPositions.Count);
        Vector3 position = enemySpawnPositions[randIndex];
        enemySpawnPositions.RemoveAt(randIndex);
        return position;
    }

    void placeObjectsAtRandom(GameObject prefab, Sprite[] sprites, Range count)
    {
        int numObjects = UnityEngine.Random.Range(count.minimum, count.maximum);

        // Place a random selection of objects on the grid anywhere but the top and bottom rows
        for (int i = 0; i < numObjects; i++)
        {
            Vector3 randPosition = getRandomGridPosition();
            GameObject tile = Instantiate(prefab, Vector3.zero, Quaternion.identity, gridHolder) as GameObject;
            tile.GetComponent<RectTransform>().anchoredPosition = randPosition;
            tile.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
            tile.GetComponent<Image>().sprite = sprites[UnityEngine.Random.Range(0, sprites.Length)];
        }
    }

    void placeEnemiesAtRandom(GameObject[] enemies)
    {
        for (int i = 0; i < enemies.Length; i++)
        {
            Vector3 spawnPosition = getRandomEnemySpawnPosition();
            GameObject enemy = Instantiate(enemies[i], Vector3.zero, Quaternion.identity, gridHolder) as GameObject;
            enemy.GetComponent<RectTransform>().anchoredPosition = spawnPosition;
            enemy.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
        }
    }

    public void loadCombatUI()
    {
        combatUI = Instantiate(combatUIPrefab, Vector3.zero, Quaternion.identity) as GameObject;
    }

    public void createGrid()
    {
        centerCamera();
        initializeGridHolder();
        initializeBackground();
        initializeGridPositions();
        placeObjectsAtRandom(obstaclePrefab, obstacleSprites, obstacleCount);
    }

    public void spawnEnemies(GameObject[] enemies)
    {
        initializeEnemySpawnPositions();
        placeEnemiesAtRandom(enemies);
    }

    public void spawnPlayer(GameObject player)
    {
        GameObject playerInstance = Instantiate(player, Vector3.zero, Quaternion.identity, gridHolder) as GameObject;
        playerInstance.GetComponent<RectTransform>().anchoredPosition = new Vector3((columns / 2) * tileScale, 0f, 0f) - tileOffset;
        playerInstance.GetComponent<RectTransform>().sizeDelta = new Vector2(tileScale, tileScale);
    }
}
